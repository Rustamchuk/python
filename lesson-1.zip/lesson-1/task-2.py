'''Пользователь вводит две буквы. Определить, на каких местах
алфавита они стоят, и сколько между ними находится букв.'''

alf = 'abcdefghijklmnopqrstuvwxyz'
first = input()
second = input()

f_index = alf.find(first) + 1
s_index = alf.find(second) + 1

count = abs(f_index - s_index)

print(f'{f_index=}, {s_index=}, {count=}')