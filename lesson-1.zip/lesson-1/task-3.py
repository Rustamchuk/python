'''Пользователь вводит номер буквы в алфавите. Определить,
какая это буква.'''

alf = 'abcdefghijklmnopqrstuvwxyz'
a = int(input())
sentence = alf[a]
print(f'{sentence=}')