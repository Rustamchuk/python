'''Вводятся три разных числа.
 Найти, какое из них является средним (больше одного, но меньше другого).'''

a = int(input())
b = int(input())
c = int(input())

if (a > b and a < c) or (a < b and a > c):
    print(f'it is {a}')
elif (b > a and a < c) or (b < a and a > c):
    print(f'it is {b}')
else:
    print(f'max 2- {c}')